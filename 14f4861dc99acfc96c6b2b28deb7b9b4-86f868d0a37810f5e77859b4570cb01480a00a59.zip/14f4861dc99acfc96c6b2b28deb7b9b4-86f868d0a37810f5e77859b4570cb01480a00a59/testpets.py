from Cat import Cat1

pet1 = Cat1('Сэм', 'мальчик', 'сибирская', 2, 'не приютили')

print('Имя питомца -', pet1.name)
print("Пол питомца -", pet1.gender)
print("Порода", pet1.breed)
print("Возраст -", pet1.age)
print("Статус -", pet1.status)

pet2 = Cat1('Барон', 'мальчик', 'сибирская', 2, 'без дома')

print('Имя питомца -', pet2.name)
print("Пол питомца -", pet2.gender)
print("Порода", pet2.breed)
print("Возраст -", pet2.age)
print("Статус -", pet2.status)